# Dreaming of Jupiter - Three.js

A Pen created on CodePen.io. Original URL: [https://codepen.io/isladjan/pen/zYqLxeG](https://codepen.io/isladjan/pen/zYqLxeG).

According to Vanga’s dreambook, seeing Jupiter in the sky promises a future disaster, when a fiery rain spills on Earth, which will kill all life and bring terrible destruction.